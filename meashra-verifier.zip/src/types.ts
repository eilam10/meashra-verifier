export interface ChainRecord {
  document: string;
  owner: string;
  subject: string;
  isActive: boolean;
  createdAt: bigint;
  updatedAt: bigint;
  expiry: bigint;
}

export type EventName =
  | "DIDRegistered"
  | "DIDUpdated"
  | "DIDRevoked"
  | "DIDTransferred"
  | "DIDExpiryChanged"
  | "DIDExpired";

export interface LogEntry {
  event: EventName;
  blockNumber: number;
  logIndex: number;
  txHash: string;
  args: Record<string, string>;
}

/** Everything the verifier needs from a chain. Implemented over ethers, or faked in tests. */
export interface ChainReader {
  label: string;
  chainId(): Promise<bigint>;
  latestBlock(): Promise<{ number: number; timestamp: number }>;
  blockTime(blockNumber: number): Promise<number>;
  computeDidId(subject: string): Promise<string>;
  getRecord(didId: string): Promise<ChainRecord | null>;
  logsFor(didId: string, fromBlock: number, toBlock: number): Promise<LogEntry[]>;
  /** Every registry event in the range, for all DIDs (used by monitor mode). */
  allLogs(fromBlock: number, toBlock: number): Promise<LogEntry[]>;
}

export interface VerifyOptions {
  registry: string;
  chainId: number;
  fromBlock: number;
  explorer: string;
  expectedIssuers: string[];
  /** A DID document the agent presented, to compare with what the chain holds. */
  presentedDocument?: string;
  /** Proof of key control: the challenge message and the agent's EIP-191 signature of it. */
  challenge?: string;
  signature?: string;
}

export type Verdict = "OK" | "WARN" | "BAD" | "INFO";

export interface Line {
  level: Verdict;
  text: string;
}

export interface HistoryItem {
  event: EventName;
  blockNumber: number;
  time: number;
  txHash: string;
  txUrl: string;
  detail: string;
}

export interface Report {
  /** The DID document exactly as stored on-chain. */
  onChainDocument?: string;
  did: string;
  subject: string;
  didId: string;
  registry: string;
  chainId: number;
  provider: string;
  latestBlock: number;
  existence: { verdict: "FOUND" | "NOT FOUND"; owner?: string; issuer?: "EXPECTED ISSUER" | "UNVERIFIED ISSUER"; lines: Line[] };
  status: {
    verdict: "ACTIVE" | "REVOKED" | "EXPIRED" | "UNKNOWN";
    at?: number;
    block?: number;
    txHash?: string;
    txUrl?: string;
    expiry?: number;
    lines: Line[];
  };
  claims: { verdict: "MATCH" | "MISMATCH" | "NOT CHECKED"; onChainHash?: string; lines: Line[] };
  key: { verdict: "PASS" | "FAIL" | "NOT CHECKED"; recovered?: string; lines: Line[] };
  history: HistoryItem[];
  overall: { verdict: "VERIFIED" | "REVOKED" | "EXPIRED" | "NOT VERIFIED" | "NOT FOUND"; reasons: string[] };
}

export interface MonitorOptions {
  registry: string;
  chainId: number;
  fromBlock: number;
  explorer: string;
  expectedIssuers: string[];
  /** The customer's own inventory: DIDs (or bare addresses) that should exist. */
  expectedDids?: string[];
}

export interface MonitorEntry {
  did: string;
  owner: string;
  issuerOk: boolean;
  status: "ACTIVE" | "REVOKED";
  registeredBlock: number;
  registeredTime: number;
  registeredTx: string;
  revokedBlock?: number;
  revokedTime?: number;
  revokedTx?: string;
  documentUpdates: number;
  expiryChanges: number;
  /** "in-inventory" | "NOT IN INVENTORY" | "" when no inventory was supplied */
  inventory: string;
}

export interface MonitorReport {
  registry: string;
  chainId: number;
  provider: string;
  latestBlock: number;
  entries: MonitorEntry[];
  findings: {
    unexpectedIssuer: string[];
    notInInventory: string[];
    inventoryNotRegistered: string[];
    inventoryRevoked: string[];
  };
  clean: boolean;
}
