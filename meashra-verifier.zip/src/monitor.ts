import { getAddress } from "ethers";
import type { ChainReader, MonitorEntry, MonitorOptions, MonitorReport } from "./types.js";
import { VerifierError } from "./core.js";

const ADDR_RE = /(0x[0-9a-fA-F]{40})\s*$/;

/** Accepts "did:nhim:<chain>:<0x..>" or a bare 0x address, one per line; '#' starts a comment. */
export function parseInventory(text: string, chainId: number): string[] {
  const out: string[] = [];
  text.split(/\r?\n/).forEach((raw, i) => {
    const line = raw.replace(/#.*/, "").trim();
    if (!line) return;
    const m = ADDR_RE.exec(line);
    if (!m) throw new VerifierError(`Inventory line ${i + 1} is not a DID or address: "${raw.trim()}"`);
    const did = /^did:nhim:/i.test(line) ? line : `did:nhim:${chainId}:${m[1]}`;
    const dm = /^did:nhim:(\d+):/i.exec(did);
    if (dm && Number(dm[1]) !== chainId) throw new VerifierError(`Inventory line ${i + 1} is for chain ${dm[1]}, not ${chainId}.`);
    out.push(`did:nhim:${chainId}:${getAddress(m[1].toLowerCase()).toLowerCase()}`);
  });
  return [...new Set(out)];
}

/**
 * Reads every registry event and lists every DID ever registered, with its status.
 * Without an inventory it flags registrations by owners that are not expected issuers.
 * With an inventory it also flags registered-but-not-in-inventory and inventory-not-registered/revoked.
 * It cannot prevent a fake registration. It makes one impossible to hide.
 */
export async function monitorRegistry(reader: ChainReader, opts: MonitorOptions): Promise<MonitorReport> {
  const rpcChain = await reader.chainId();
  if (Number(rpcChain) !== opts.chainId) {
    throw new VerifierError(`The RPC endpoint is on chain ${rpcChain}, not ${opts.chainId} (Sepolia). Use a Sepolia RPC URL.`);
  }
  const latest = await reader.latestBlock();
  const logs = await reader.allLogs(opts.fromBlock, latest.number);
  logs.sort((a, b) => a.blockNumber - b.blockNumber || a.logIndex - b.logIndex);

  const issuers = new Set(opts.expectedIssuers.map((a) => a.toLowerCase()));
  const times = new Map<number, number>();
  const timeOf = async (bn: number) => {
    if (!times.has(bn)) times.set(bn, await reader.blockTime(bn));
    return times.get(bn)!;
  };

  const byId = new Map<string, MonitorEntry>();
  for (const l of logs) {
    const id = (l.args.didId ?? "").toLowerCase();
    if (!id) continue;
    if (l.event === "DIDRegistered") {
      const did = `did:nhim:${opts.chainId}:${l.args.subject.toLowerCase()}`;
      byId.set(id, {
        did, owner: l.args.owner, issuerOk: issuers.has(l.args.owner.toLowerCase()), status: "ACTIVE",
        registeredBlock: l.blockNumber, registeredTime: await timeOf(l.blockNumber), registeredTx: l.txHash,
        documentUpdates: 0, expiryChanges: 0, inventory: "",
      });
      continue;
    }
    const e = byId.get(id);
    if (!e) continue; // event for a DID whose registration is before the searched range
    if (l.event === "DIDRevoked") {
      e.status = "REVOKED"; e.revokedBlock = l.blockNumber; e.revokedTime = await timeOf(l.blockNumber); e.revokedTx = l.txHash;
    } else if (l.event === "DIDUpdated") e.documentUpdates++;
    else if (l.event === "DIDExpiryChanged") e.expiryChanges++;
  }

  const entries = [...byId.values()].sort((a, b) => a.registeredBlock - b.registeredBlock);
  const findings = { unexpectedIssuer: [] as string[], notInInventory: [] as string[], inventoryNotRegistered: [] as string[], inventoryRevoked: [] as string[] };

  const inv = opts.expectedDids ? new Set(opts.expectedDids.map((d) => d.toLowerCase())) : null;
  for (const e of entries) {
    if (!e.issuerOk) findings.unexpectedIssuer.push(e.did);
    if (inv) {
      const inInv = inv.has(e.did);
      e.inventory = inInv ? "in inventory" : "NOT IN INVENTORY";
      if (!inInv && e.status === "ACTIVE") findings.notInInventory.push(e.did);
    }
  }
  if (inv) {
    const seen = new Map(entries.map((e) => [e.did, e]));
    for (const d of inv) {
      const e = seen.get(d);
      if (!e) findings.inventoryNotRegistered.push(d);
      else if (e.status === "REVOKED") findings.inventoryRevoked.push(d);
    }
  }
  const clean = Object.values(findings).every((a) => a.length === 0);
  return { registry: opts.registry, chainId: opts.chainId, provider: reader.label, latestBlock: latest.number, entries, findings, clean };
}

const iso = (t: number) => new Date(t * 1000).toISOString().replace(".000Z", "Z");

export function renderMonitor(r: MonitorReport, explorer: string, hadInventory: boolean): string {
  const out: string[] = [];
  out.push(`MONITOR    registry ${r.registry} (chain ${r.chainId})  ${explorer}/address/${r.registry}`);
  out.push(`RPC        ${r.provider}   latest block ${r.latestBlock}`);
  out.push("", `${r.entries.length} DIDs ever registered (${r.entries.filter((e) => e.status === "ACTIVE").length} active, ${r.entries.filter((e) => e.status === "REVOKED").length} revoked)`, "");
  for (const e of r.entries) {
    out.push(`${e.status.padEnd(7)} ${e.did}${hadInventory ? "   [" + e.inventory + "]" : ""}`);
    out.push(`        registered ${iso(e.registeredTime)} block ${e.registeredBlock} by ${e.owner}${e.issuerOk ? "" : "   <-- NOT AN EXPECTED ISSUER"}`);
    out.push(`        ${explorer}/tx/${e.registeredTx}`);
    if (e.status === "REVOKED") out.push(`        revoked    ${iso(e.revokedTime!)} block ${e.revokedBlock}  ${explorer}/tx/${e.revokedTx}`);
    if (e.documentUpdates || e.expiryChanges) out.push(`        ${e.documentUpdates} document update(s), ${e.expiryChanges} expiry change(s) logged`);
  }
  const f = r.findings;
  out.push("", "FINDINGS");
  const sect = (title: string, list: string[]) => { if (list.length) { out.push(`  ${title}`); list.forEach((d) => out.push(`    ${d}`)); } };
  sect("Registered by an owner that is not an expected issuer:", f.unexpectedIssuer);
  sect("Active in the registry but NOT in your inventory:", f.notInInventory);
  sect("In your inventory but never registered:", f.inventoryNotRegistered);
  sect("In your inventory but revoked on-chain:", f.inventoryRevoked);
  if (r.clean) out.push(hadInventory ? "  none: the registry matches your inventory." : "  none (no inventory supplied, so only issuer checks ran).");
  out.push("", hadInventory ? "RESULT: " + (r.clean ? "MATCHES INVENTORY" : "REVIEW FINDINGS") : "RESULT: " + (r.clean ? "NO ISSUER ANOMALIES" : "REVIEW FINDINGS"));
  out.push("Monitoring cannot stop a registration. It makes one impossible to hide: everything above is read from public chain data. It trusts the RPC provider you used.");
  return out.join("\n");
}
