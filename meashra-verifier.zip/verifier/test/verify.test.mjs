import test from "node:test";
import assert from "node:assert/strict";
import { Wallet } from "ethers";
import { verifyDid, makeChallenge, compareReports } from "../dist/core.mjs";

const REG = "0x57F1475b01E867F0E3E2bA1123c5c9F7021E548b";
const ISSUER = "0x7968dDA24aF04BEfF495e24Aa3655c5b3F2238F3";
const OTHER = "0x00000000000000000000000000000000000000aa";
const BASE = { registry: REG, chainId: 11155111, fromBlock: 1, explorer: "https://sepolia.etherscan.io", expectedIssuers: [ISSUER] };
const agent = Wallet.createRandom();
const did = `did:nhim:11155111:${agent.address.toLowerCase()}`;
const docObj = (id = did, addr = agent.address.toLowerCase()) => ({
  "@context": ["https://www.w3.org/ns/did/v1"], id, controller: id,
  verificationMethod: [{ id: id + "#k1", type: "EcdsaSecp256k1RecoveryMethod2020", controller: id, blockchainAccountId: `eip155:11155111:${addr}` }],
  authentication: [id + "#k1"],
});
const DOC = JSON.stringify(docObj());
const tx = (n) => "0x" + n.toString(16).padStart(64, "0");

function fake({ owner = ISSUER, active = true, expiry = 0n, logs, document = DOC, subject = agent.address, chain = 11155111n, record = true } = {}) {
  const base = [{ event: "DIDRegistered", blockNumber: 100, logIndex: 0, txHash: tx(1), args: { owner, subject: agent.address, document: DOC } }];
  return {
    label: "fake",
    chainId: async () => chain,
    latestBlock: async () => ({ number: 500, timestamp: 2_000_000 }),
    blockTime: async (n) => 1_000_000 + n,
    computeDidId: async () => tx(99),
    getRecord: async () => (record ? { document, owner, subject, isActive: active, createdAt: 1n, updatedAt: 1n, expiry } : null),
    logsFor: async () => logs ?? base,
  };
}

test("1 active agent -> ACTIVE, VERIFIED, tx link", async () => {
  const r = await verifyDid(did, fake(), BASE);
  assert.equal(r.existence.verdict, "FOUND");
  assert.equal(r.existence.issuer, "EXPECTED ISSUER");
  assert.equal(r.status.verdict, "ACTIVE");
  assert.match(r.status.txUrl, /^https:\/\/sepolia\.etherscan\.io\/tx\/0x/);
  assert.equal(r.claims.verdict, "MATCH");
  assert.equal(r.overall.verdict, "VERIFIED");
  assert.equal(r.history.length, 1);
});

test("2 revoked agent -> REVOKED with time and tx", async () => {
  const logs = [
    { event: "DIDRegistered", blockNumber: 100, logIndex: 0, txHash: tx(1), args: { owner: ISSUER, subject: agent.address, document: DOC } },
    { event: "DIDRevoked", blockNumber: 200, logIndex: 0, txHash: tx(2), args: {} },
  ];
  const r = await verifyDid(did, fake({ active: false, logs }), BASE);
  assert.equal(r.status.verdict, "REVOKED");
  assert.equal(r.status.at, 1_000_200);
  assert.equal(r.status.txHash, tx(2));
  assert.equal(r.overall.verdict, "REVOKED"); // genuine issuer, but never headlined VERIFIED
});

test("2b revoked event but state still active -> flagged inconsistent", async () => {
  const logs = [
    { event: "DIDRegistered", blockNumber: 100, logIndex: 0, txHash: tx(1), args: { owner: ISSUER, subject: agent.address, document: DOC } },
    { event: "DIDRevoked", blockNumber: 200, logIndex: 0, txHash: tx(2), args: {} },
  ];
  const r = await verifyDid(did, fake({ active: true, logs }), BASE);
  assert.equal(r.overall.verdict, "NOT VERIFIED");
});

test("3 unknown DID -> NOT FOUND", async () => {
  const r = await verifyDid(did, fake({ record: false, logs: [] }), BASE);
  assert.equal(r.existence.verdict, "NOT FOUND");
  assert.equal(r.overall.verdict, "NOT FOUND");
});

test("4 altered claims -> MISMATCH", async () => {
  const altered = JSON.stringify({ ...docObj(), controller: "did:nhim:11155111:0xdeadbeef" });
  const r = await verifyDid(did, fake(), { ...BASE, presentedDocument: altered });
  assert.equal(r.claims.verdict, "MISMATCH");
  assert.equal(r.overall.verdict, "NOT VERIFIED");
});

test("4b same content, different formatting -> MATCH", async () => {
  const pretty = JSON.stringify(docObj(), null, 2);
  const r = await verifyDid(did, fake(), { ...BASE, presentedDocument: pretty });
  assert.equal(r.claims.verdict, "MATCH");
});

test("4c state differs from latest event document -> MISMATCH", async () => {
  const r = await verifyDid(did, fake({ document: JSON.stringify({ ...docObj(), extra: 1 }) }), BASE);
  assert.equal(r.claims.verdict, "MISMATCH");
});

test("5 key control: right key PASS, wrong key FAIL, wrong DID in challenge FAIL", async () => {
  const msg = makeChallenge(did, REG);
  const good = await agent.signMessage(msg);
  assert.equal((await verifyDid(did, fake(), { ...BASE, challenge: msg, signature: good })).key.verdict, "PASS");
  const bad = await Wallet.createRandom().signMessage(msg);
  const rb = await verifyDid(did, fake(), { ...BASE, challenge: msg, signature: bad });
  assert.equal(rb.key.verdict, "FAIL");
  assert.equal(rb.overall.verdict, "NOT VERIFIED");
  const other = makeChallenge("did:nhim:11155111:0x" + "11".repeat(20), REG);
  const rc = await verifyDid(did, fake(), { ...BASE, challenge: other, signature: await agent.signMessage(other) });
  assert.equal(rc.key.verdict, "FAIL");
});

test("6 lookalike owner (not an expected issuer) -> UNVERIFIED ISSUER, NOT VERIFIED", async () => {
  const logs = [{ event: "DIDRegistered", blockNumber: 100, logIndex: 0, txHash: tx(1), args: { owner: OTHER, subject: agent.address, document: DOC } }];
  const r = await verifyDid(did, fake({ owner: OTHER, logs }), BASE);
  assert.equal(r.existence.issuer, "UNVERIFIED ISSUER");
  assert.equal(r.overall.verdict, "NOT VERIFIED");
});

test("7 silent expiry change (state has expiry, no event) -> warning", async () => {
  const r = await verifyDid(did, fake({ expiry: 5_000_000n }), BASE);
  assert.ok(r.status.lines.some((l) => l.level === "WARN" && /does not match the last DIDExpiryChanged/.test(l.text)));
});

test("7b logged expiry change -> no warning", async () => {
  const logs = [
    { event: "DIDRegistered", blockNumber: 100, logIndex: 0, txHash: tx(1), args: { owner: ISSUER, subject: agent.address, document: DOC } },
    { event: "DIDExpiryChanged", blockNumber: 150, logIndex: 0, txHash: tx(3), args: { expiry: "5000000", by: ISSUER } },
  ];
  const r = await verifyDid(did, fake({ expiry: 5_000_000n, logs }), BASE);
  assert.ok(!r.status.lines.some((l) => l.level === "WARN"));
});

test("8 expired by the chain clock -> EXPIRED", async () => {
  const r = await verifyDid(did, fake({ expiry: 1_500_000n, logs: [{ event: "DIDRegistered", blockNumber: 100, logIndex: 0, txHash: tx(1), args: { owner: ISSUER, subject: agent.address, document: DOC } }, { event: "DIDExpiryChanged", blockNumber: 101, logIndex: 0, txHash: tx(4), args: { expiry: "1500000", by: ISSUER } }] }), BASE);
  assert.equal(r.status.verdict, "EXPIRED");
});

test("guards: wrong-chain DID, wrong-chain RPC, ABI/struct mismatch all refuse", async () => {
  await assert.rejects(verifyDid("did:nhim:1:" + agent.address, fake(), BASE), /pinned to chain/);
  await assert.rejects(verifyDid(did, fake({ chain: 1n }), BASE), /not 11155111/);
  await assert.rejects(verifyDid(did, fake({ subject: OTHER }), BASE), /does not match the deployed contract/);
  await assert.rejects(verifyDid("not-a-did", fake(), BASE), /Not a did:nhim/);
});

test("two providers: agree, and disagree when one lies", async () => {
  const a = await verifyDid(did, fake(), BASE);
  const b = await verifyDid(did, fake(), BASE);
  assert.deepEqual(compareReports(a, b), []);
  const c = await verifyDid(did, fake({ active: false }), BASE);
  assert.ok(compareReports(a, c).length > 0);
});
