import test from "node:test";
import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { writeFileSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Wallet, keccak256 } from "ethers";
import { startMock } from "./mock-rpc.mjs";

const REG = "0x57F1475b01E867F0E3E2bA1123c5c9F7021E548b";
const ISSUER = "0x7968dDA24aF04BEfF495e24Aa3655c5b3F2238F3";
const agent = Wallet.createRandom();
const did = `did:nhim:11155111:${agent.address.toLowerCase()}`;
const DOC = JSON.stringify({ id: did, verificationMethod: [{ blockchainAccountId: `eip155:11155111:${agent.address.toLowerCase()}` }] });
const tx = (n) => "0x" + n.toString(16).padStart(64, "0");
const didId = keccak256(agent.address.toLowerCase());
const reg = (block) => ({ name: "DIDRegistered", block, tx: tx(1), args: [didId, agent.address, ISSUER, DOC] });
const base = { registry: REG, subject: agent.address, owner: ISSUER, active: true, document: DOC, exists: true, expiry: 0, latest: { number: 11869000, timestamp: 1791450000 }, logs: [reg(11863500)] };

function run(args) {
  return new Promise((resolve) => {
    execFile("node", ["dist/cli.js", ...args], { encoding: "utf8", timeout: 20000 }, (err, stdout, stderr) =>
      resolve({ code: err ? (typeof err.code === "number" ? err.code : 99) : 0, out: stdout + stderr, stdout }));
  });
}
const cli = (url, ...extra) => run([did, "--rpc", url, ...extra]);

test("e2e: active agent through the real ethers reader", async () => {
  const m = await startMock(base); const r = await cli(m.url); m.close();
  assert.equal(r.code, 0, r.out);
  assert.match(r.out, /1\. EXISTENCE: FOUND \/ EXPECTED ISSUER/);
  assert.match(r.out, /2\. STATUS: ACTIVE/);
  assert.match(r.out, /RESULT: VERIFIED/);
  assert.match(r.out, /DIDRegistered/);
  assert.match(r.out, /sepolia\.etherscan\.io\/tx\/0x0000/);
});

test("e2e: revoked agent shows time", async () => {
  const m = await startMock({ ...base, active: false, logs: [reg(11863500), { name: "DIDRevoked", block: 11864000, tx: tx(2), args: [didId] }] });
  const r = await cli(m.url); m.close();
  assert.equal(r.code, 1, r.out); // revoked must not pass a script gate
  assert.match(r.out, /RESULT: REVOKED/);
  assert.match(r.out, /2\. STATUS: REVOKED/);
  assert.match(r.out, /Revoked in block 11864000 at 20\d\d-/);
});

test("e2e: unknown DID", async () => {
  const m = await startMock({ ...base, exists: false, logs: [] }); const r = await cli(m.url); m.close();
  assert.equal(r.code, 1, r.out);
  assert.match(r.out, /EXISTENCE: NOT FOUND/);
});

test("e2e: lookalike registered by someone else", async () => {
  const other = Wallet.createRandom().address;
  const m = await startMock({ ...base, owner: other, logs: [{ ...reg(11863500), args: [didId, agent.address, other, DOC] }] });
  const r = await cli(m.url); m.close();
  assert.equal(r.code, 1, r.out);
  assert.match(r.out, /UNVERIFIED ISSUER/);
  assert.match(r.out, /NOT VERIFIED/);
});

test("e2e: altered presented document", async () => {
  const dir = mkdtempSync(join(tmpdir(), "v-")); const f = join(dir, "doc.json");
  writeFileSync(f, JSON.stringify({ id: did, extra: "forged" }));
  const m = await startMock(base); const r = await cli(m.url, "--doc", f); m.close();
  assert.equal(r.code, 1, r.out);
  assert.match(r.out, /CLAIMS INTEGRITY: MISMATCH/);
});

test("e2e: key control pass and fail via CLI flow", async () => {
  const dir = mkdtempSync(join(tmpdir(), "v-"));
  const chal = (await run([did, "--challenge"])).stdout.replace(/\n$/, "");
  const mf = join(dir, "msg.txt"); writeFileSync(mf, chal);
  const m = await startMock(base);
  const good = await cli(m.url, "--message-file", mf, "--signature", await agent.signMessage(chal));
  const bad = await cli(m.url, "--message-file", mf, "--signature", await Wallet.createRandom().signMessage(chal));
  m.close();
  assert.equal(good.code, 0, good.out); assert.match(good.out, /CONTROL OF KEY: PASS/);
  assert.equal(bad.code, 1, bad.out); assert.match(bad.out, /CONTROL OF KEY: FAIL/);
});

test("e2e: provider with a small log-range limit still works (chunking)", async () => {
  const m = await startMock({ ...base, maxRange: 5000 }); const r = await cli(m.url); m.close();
  assert.equal(r.code, 0, r.out);
  assert.match(r.out, /DIDRegistered/);
});

test("e2e: wrong-chain RPC is refused", async () => {
  const m = await startMock({ ...base, chainId: 1 }); const r = await cli(m.url); m.close();
  assert.equal(r.code, 2, r.out);
  assert.match(r.out, /not 11155111/);
});

test("e2e: silent expiry change is warned", async () => {
  const m = await startMock({ ...base, expiry: 1791999999 }); const r = await cli(m.url); m.close();
  assert.match(r.out, /does not match the last DIDExpiryChanged/);
});

test("e2e: two providers cross-check agree", async () => {
  const a = await startMock(base), b = await startMock(base);
  const r = await run([did, "--rpc", a.url, "--rpc", b.url]);
  a.close(); b.close();
  assert.equal(r.code, 0, r.out);
  assert.match(r.stdout, /2 providers agree/);
});
