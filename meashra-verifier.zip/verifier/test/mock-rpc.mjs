// Minimal Sepolia-like JSON-RPC server for end-to-end tests of the real ethers reader.
import http from "node:http";
import { Interface, keccak256 } from "ethers";
import { ABI } from "../dist/abi.mjs";

export const iface = new Interface(ABI);

export function startMock(scenario) {
  const calls = [];
  const blockObj = (n, ts) => ({
    number: "0x" + n.toString(16), hash: keccak256("0x" + n.toString(16).padStart(8, "0")), parentHash: "0x" + "00".repeat(32),
    nonce: "0x0000000000000000", sha3Uncles: "0x" + "00".repeat(32), logsBloom: "0x" + "00".repeat(256),
    transactionsRoot: "0x" + "00".repeat(32), stateRoot: "0x" + "00".repeat(32), receiptsRoot: "0x" + "00".repeat(32),
    miner: "0x" + "00".repeat(20), difficulty: "0x0", totalDifficulty: "0x0", extraData: "0x", size: "0x1",
    gasLimit: "0x1c9c380", gasUsed: "0x0", timestamp: "0x" + ts.toString(16), transactions: [], uncles: [],
  });
  const server = http.createServer((req, res) => {
    if (req.method === "OPTIONS") { res.writeHead(204, { "access-control-allow-origin": "*", "access-control-allow-headers": "content-type" }); res.end(); return; }
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      const handle = (m) => {
        calls.push(m.method);
        const ok = (result) => ({ jsonrpc: "2.0", id: m.id, result });
        switch (m.method) {
          case "eth_chainId": return ok("0x" + (scenario.chainId ?? 11155111).toString(16));
          case "eth_getBlockByNumber": {
            const p = m.params[0];
            const n = p === "latest" ? scenario.latest.number : parseInt(p, 16);
            const ts = p === "latest" ? scenario.latest.timestamp : scenario.latest.timestamp - (scenario.latest.number - n) * 12;
            return ok(blockObj(n, ts));
          }
          case "eth_call": {
            const data = m.params[0].data;
            const parsed = iface.parseTransaction({ data });
            if (parsed.name === "computeDidId") return ok(keccak256(parsed.args[0].toLowerCase()));
            if (parsed.name === "getRecord") {
              if (!scenario.exists) return { jsonrpc: "2.0", id: m.id, error: { code: 3, message: "execution reverted", data: "0x" } };
              return ok(iface.encodeFunctionResult("getRecord", [[scenario.document, scenario.owner, scenario.subject, scenario.active, 1n, 1n, BigInt(scenario.expiry ?? 0)]]));
            }
            return { jsonrpc: "2.0", id: m.id, error: { code: -32601, message: "unsupported call" } };
          }
          case "eth_getLogs": {
            const f = m.params[0];
            const from = parseInt(f.fromBlock, 16), to = parseInt(f.toBlock, 16);
            if (scenario.maxRange && to - from + 1 > scenario.maxRange) return { jsonrpc: "2.0", id: m.id, error: { code: -32005, message: "query exceeds max block range" } };
            const out = scenario.logs.filter((l) => l.block >= from && l.block <= to).map((l, i) => {
              const ev = iface.encodeEventLog(iface.getEvent(l.name), l.args);
              return { address: scenario.registry.toLowerCase(), topics: ev.topics, data: ev.data, blockNumber: "0x" + l.block.toString(16), transactionHash: l.tx, transactionIndex: "0x0", blockHash: keccak256("0x" + l.block.toString(16).padStart(8, "0")), logIndex: "0x" + i.toString(16), removed: false };
            });
            return ok(out);
          }
          default: return { jsonrpc: "2.0", id: m.id, error: { code: -32601, message: "method not found " + m.method } };
        }
      };
      const msg = JSON.parse(body);
      const resp = Array.isArray(msg) ? msg.map(handle) : handle(msg);
      res.setHeader("content-type", "application/json");
      res.setHeader("access-control-allow-origin", "*");
      res.end(JSON.stringify(resp));
    });
  });
  return new Promise((resolve) => server.listen(0, "127.0.0.1", () => resolve({ url: `http://127.0.0.1:${server.address().port}`, close: () => { server.close(); server.closeAllConnections?.(); }, calls })));
}
