// For the AGENT HOLDER only. Signs a verifier challenge with the agent's key (EIP-191 personal sign).
// The private key is read from the AGENT_PRIVATE_KEY environment variable. It is never printed or sent anywhere.
//   AGENT_PRIVATE_KEY=0x... node dist/sign.js challenge.txt
import { readFileSync } from "node:fs";
import { Wallet } from "ethers";

const file = process.argv[2];
const key = process.env.AGENT_PRIVATE_KEY;
if (!file || !key) { console.error("Usage: AGENT_PRIVATE_KEY=0x... node dist/sign.js <challenge-file>"); process.exit(2); }
const message = readFileSync(file, "utf8").replace(/\r?\n$/, "");
const wallet = new Wallet(key);
console.error("Signing as " + wallet.address);
console.log(await wallet.signMessage(message));
