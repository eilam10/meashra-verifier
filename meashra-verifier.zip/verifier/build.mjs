import { build } from "esbuild";
await build({ entryPoints: ["src/cli.ts"], bundle: true, platform: "node", format: "esm", target: "node18", outfile: "dist/cli.js", banner: { js: "#!/usr/bin/env node\nimport { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" }, logLevel: "info" });
await build({ entryPoints: ["src/web.ts"], bundle: true, platform: "browser", format: "iife", globalName: "MeashraVerifier", target: "es2020", minify: true, outfile: "web/verifier.js", logLevel: "info" });
await build({ entryPoints: ["src/core.ts"], bundle: true, platform: "node", format: "esm", target: "node18", outfile: "dist/core.mjs", logLevel: "silent" });
await build({ entryPoints: ["src/config.ts"], bundle: false, platform: "node", format: "esm", outfile: "dist/abi.mjs", logLevel: "silent" });
await build({ entryPoints: ["src/config.ts"], bundle: false, platform: "node", format: "esm", outfile: "dist/abi.mjs", logLevel: "silent" });
await build({ entryPoints: ["examples/sign.mjs"], bundle: true, platform: "node", format: "esm", target: "node18", outfile: "dist/sign.js", logLevel: "silent", banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" } });
