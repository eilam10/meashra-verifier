import { readFileSync } from "node:fs";
import { REGISTRY, DEFAULT_PUBLIC_RPC } from "./config.js";
import { verifyDid, makeChallenge, compareReports, VerifierError } from "./core.js";
import { ethersReader } from "./reader.js";
import { renderText } from "./render.js";
import type { Report } from "./types.js";

const USAGE = `Meashra external verifier (read-only; talks only to the RPC URL you give it)

Usage:
  verify did:nhim:<chainId>:<address> --rpc <url> [options]

Options:
  --rpc <url>            Sepolia RPC URL. Repeat it to cross-check two providers.
                         (default: ${DEFAULT_PUBLIC_RPC})
  --challenge            Print a fresh challenge for the agent to sign, then exit.
  --signature <0x...>    The agent's signature of that challenge (check 4).
  --message-file <path>  File holding the exact challenge text that was signed.
  --doc <path>           A DID document the agent presented, to compare with the chain.
  --issuer <0x...>       Expected issuer address. Repeat to allow several.
                         (default: ${REGISTRY.defaultIssuers.join(", ")})
  --registry <0x...>     Check a different registry (requires --from-block).
  --from-block <n>       First block to search for events (default: ${REGISTRY.deployBlock}).
  --json                 Print the report as JSON.
  --print-doc            Print the DID document stored on-chain, and nothing else.

Exit code: 0 verified or revoked-but-genuine, 1 not verified / not found, 2 usage or RPC error.`;

function parseArgs(argv: string[]) {
  const a: { did?: string; rpc: string[]; issuer: string[]; json: boolean; challenge: boolean; [k: string]: any } = { rpc: [], issuer: [], json: false, challenge: false };
  for (let i = 0; i < argv.length; i++) {
    const t = argv[i];
    const next = () => { const v = argv[++i]; if (v === undefined) throw new VerifierError(`Missing value after ${t}`); return v; };
    if (t === "--rpc") a.rpc.push(next());
    else if (t === "--issuer") a.issuer.push(next());
    else if (t === "--signature") a.signature = next();
    else if (t === "--message-file") a.messageFile = next();
    else if (t === "--doc") a.doc = next();
    else if (t === "--registry") a.registry = next();
    else if (t === "--from-block") a.fromBlock = Number(next());
    else if (t === "--json") a.json = true;
    else if (t === "--print-doc") a.printDoc = true;
    else if (t === "--challenge") a.challenge = true;
    else if (t === "-h" || t === "--help") { console.log(USAGE); process.exit(0); }
    else if (t.startsWith("--")) throw new VerifierError(`Unknown option ${t}`);
    else if (!a.did) a.did = t;
    else throw new VerifierError(`Unexpected argument ${t}`);
  }
  return a;
}

async function main() {
  const a = parseArgs(process.argv.slice(2));
  if (!a.did) { console.log(USAGE); process.exit(2); }
  const registry: string = a.registry ?? REGISTRY.address;
  if (a.registry && a.fromBlock === undefined) throw new VerifierError("--registry needs --from-block (the block that registry was deployed in).");
  const fromBlock: number = a.fromBlock ?? REGISTRY.deployBlock;

  if (a.challenge) {
    console.log(makeChallenge(a.did, registry));
    console.error("\nHave the agent sign the text above exactly as printed (EIP-191 personal_sign), save it to a file, and pass --message-file <file> --signature <sig>.");
    return;
  }

  const rpcs = a.rpc.length ? a.rpc : [DEFAULT_PUBLIC_RPC];
  const opts = {
    registry, chainId: REGISTRY.chainId, fromBlock, explorer: REGISTRY.explorer,
    expectedIssuers: a.issuer.length ? a.issuer : REGISTRY.defaultIssuers,
    presentedDocument: a.doc ? readFileSync(a.doc, "utf8") : undefined,
    challenge: a.messageFile ? readFileSync(a.messageFile, "utf8").replace(/\r?\n$/, "") : undefined,
    signature: a.signature,
  };
  if (a.signature && !opts.challenge) throw new VerifierError("--signature needs --message-file (the exact text that was signed).");

  const reports: Report[] = [];
  for (const url of rpcs) reports.push(await verifyDid(a.did, ethersReader(url, registry, REGISTRY.chainId), opts));

  let diffs: string[] = [];
  if (reports.length > 1) for (let i = 1; i < reports.length; i++) diffs = diffs.concat(compareReports(reports[0], reports[i]));

  if (a.printDoc) {
    if (reports[0].onChainDocument === undefined) { console.error("No record found, nothing to print."); process.exit(1); }
    console.log(reports[0].onChainDocument);
    process.exit(0);
  }
  if (a.json) {
    console.log(JSON.stringify({ reports, providersAgree: reports.length > 1 ? diffs.length === 0 : null, differences: diffs }, (_k, v) => (typeof v === "bigint" ? v.toString() : v), 2));
  } else {
    console.log(renderText(reports[0], REGISTRY.explorer));
    if (reports.length > 1) console.log("\nCROSS-CHECK: " + (diffs.length ? "PROVIDERS DISAGREE\n  " + diffs.join("\n  ") : `${reports.length} providers agree`));
  }
  const bad = reports[0].overall.verdict !== "VERIFIED" || diffs.length > 0;
  process.exit(bad ? 1 : 0);
}

main().catch((e) => {
  if (e instanceof VerifierError) { console.error("Error: " + e.message); process.exit(2); }
  console.error(e); process.exit(2);
});
