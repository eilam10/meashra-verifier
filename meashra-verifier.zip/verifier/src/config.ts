// Pinned deployment. Everything else is read from the chain.
export const REGISTRY = {
  address: "0x57F1475b01E867F0E3E2bA1123c5c9F7021E548b",
  chainId: 11155111,
  chainName: "Ethereum Sepolia (testnet)",
  deployBlock: 11863194,
  explorer: "https://sepolia.etherscan.io",
  // Addresses that Meashra says are legitimate issuers (owner of a record = the wallet
  // that called registerDID). A record whose owner is not in this list is reported
  // as UNVERIFIED ISSUER, never as verified.
  defaultIssuers: ["0x7968dDA24aF04BEfF495e24Aa3655c5b3F2238F3"],
};

export const DEFAULT_PUBLIC_RPC = "https://ethereum-sepolia-rpc.publicnode.com";

export const ABI = [
  "event DIDRegistered(bytes32 indexed didId, address indexed subject, address indexed owner, string document)",
  "event DIDUpdated(bytes32 indexed didId, string newDocument)",
  "event DIDRevoked(bytes32 indexed didId)",
  "event DIDTransferred(bytes32 indexed didId, address indexed previousOwner, address indexed newOwner)",
  "event DIDExpiryChanged(bytes32 indexed didId, uint256 expiry, address indexed by)",
  "event DIDExpired(bytes32 indexed didId, uint256 expiryTimestamp)",
  "function computeDidId(address subject) view returns (bytes32)",
  "function getRecord(bytes32 didId) view returns (tuple(string document, address owner, address subject, bool isActive, uint256 createdAt, uint256 updatedAt, uint256 expiry))",
];
