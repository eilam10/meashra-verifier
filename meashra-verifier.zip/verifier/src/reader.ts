import { Contract, Interface, JsonRpcProvider, Network } from "ethers";
import { ABI } from "./config.js";
import type { ChainReader, ChainRecord, EventName, LogEntry } from "./types.js";
import { VerifierError } from "./core.js";

export function ethersReader(rpcUrl: string, registry: string, chainId: number): ChainReader {
  let host = rpcUrl;
  try { host = new URL(rpcUrl).host; } catch { /* keep raw */ }
  // staticNetwork: no hidden network-detection calls; we check eth_chainId explicitly.
  const provider = new JsonRpcProvider(rpcUrl, Network.from(chainId), { staticNetwork: Network.from(chainId), batchMaxCount: 1 });
  const iface = new Interface(ABI);
  const contract = new Contract(registry, iface, provider);
  const blockTimes = new Map<number, number>();

  const wrap = async <T>(what: string, f: () => Promise<T>): Promise<T> => {
    try { return await f(); } catch (e: any) {
      throw new VerifierError(`RPC problem while ${what} (${host}): ${e?.shortMessage ?? e?.message ?? e}`);
    }
  };

  return {
    label: host,
    chainId: () => wrap("reading chain id", async () => BigInt(await provider.send("eth_chainId", []))),
    latestBlock: () => wrap("reading the latest block", async () => {
      const b = await provider.getBlock("latest");
      if (!b) throw new Error("no block");
      blockTimes.set(b.number, b.timestamp);
      return { number: b.number, timestamp: b.timestamp };
    }),
    blockTime: (n) => wrap(`reading block ${n}`, async () => {
      const cached = blockTimes.get(n);
      if (cached !== undefined) return cached;
      const b = await provider.getBlock(n);
      if (!b) throw new Error("block not found");
      blockTimes.set(n, b.timestamp);
      return b.timestamp;
    }),
    computeDidId: (subject) => wrap("computing the DID id", async () => (await contract.computeDidId(subject)) as string),
    getRecord: async (didId): Promise<ChainRecord | null> => {
      let r: any;
      try {
        r = await contract.getRecord(didId);
      } catch (e: any) {
        // A revert from the registry means "no such record"; anything else is an RPC problem.
        if (e?.code === "CALL_EXCEPTION") return null;
        throw new VerifierError(`RPC problem while reading the record (${host}): ${e?.shortMessage ?? e?.message ?? e}`);
      }
      return {
        document: r.document, owner: r.owner, subject: r.subject, isActive: r.isActive,
        createdAt: BigInt(r.createdAt), updatedAt: BigInt(r.updatedAt), expiry: BigInt(r.expiry),
      };
    },
    logsFor: (didId, fromBlock, toBlock) => wrap("reading event logs", async () => {
      const out: LogEntry[] = [];
      let span = 200_000;
      let start = fromBlock;
      while (start <= toBlock) {
        const end = Math.min(start + span - 1, toBlock);
        let logs;
        try {
          logs = await provider.getLogs({ address: registry, fromBlock: start, toBlock: end, topics: [null as any, didId] });
        } catch (e) {
          if (span <= 1000) throw e; // provider rejects even small ranges
          span = Math.floor(span / 4);
          continue;
        }
        for (const l of logs) {
          const parsed = iface.parseLog({ topics: [...l.topics], data: l.data });
          if (!parsed) continue;
          const args: Record<string, string> = {};
          parsed.fragment.inputs.forEach((inp, i) => { args[inp.name] = String(parsed.args[i]); });
          out.push({ event: parsed.name as EventName, blockNumber: l.blockNumber, logIndex: l.index, txHash: l.transactionHash, args });
        }
        start = end + 1;
      }
      return out;
    }),
  };
}
