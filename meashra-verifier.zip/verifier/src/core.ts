import { getAddress, keccak256, toUtf8Bytes, verifyMessage, hexlify, randomBytes } from "ethers";
import type {
  ChainReader, ChainRecord, HistoryItem, Line, LogEntry, Report, VerifyOptions,
} from "./types.js";

const ZERO = "0x0000000000000000000000000000000000000000";
const DID_RE = /^did:nhim:(\d+):(0x[0-9a-fA-F]{40})$/;

export class VerifierError extends Error {}

export function parseDid(did: string): { chainId: number; subject: string } {
  const m = DID_RE.exec(did.trim());
  if (!m) throw new VerifierError(`Not a did:nhim identifier: "${did}". Expected did:nhim:<chainId>:<0x address>.`);
  return { chainId: Number(m[1]), subject: getAddress(m[2].toLowerCase()) };
}

export function makeChallenge(did: string, registry: string): string {
  const nonce = hexlify(randomBytes(16));
  return `Meashra verification challenge\nDID: ${did.trim().toLowerCase()}\nRegistry: ${registry.toLowerCase()}\nNonce: ${nonce}`;
}

function same(a: string, b: string): boolean {
  return a.toLowerCase() === b.toLowerCase();
}

/** Stable form of a JSON text so that whitespace/key-order differences are not reported as tampering. */
function canonicalJson(text: string): string | null {
  try {
    const sort = (v: unknown): unknown =>
      Array.isArray(v) ? v.map(sort)
        : v && typeof v === "object"
          ? Object.fromEntries(Object.entries(v as Record<string, unknown>).sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, x]) => [k, sort(x)]))
          : v;
    return JSON.stringify(sort(JSON.parse(text)));
  } catch {
    return null;
  }
}

const hashOf = (s: string) => keccak256(toUtf8Bytes(s));

function detailFor(l: LogEntry): string {
  switch (l.event) {
    case "DIDRegistered": return `owner ${l.args.owner}; document hash ${hashOf(l.args.document).slice(0, 18)}…`;
    case "DIDUpdated": return `new document hash ${hashOf(l.args.newDocument).slice(0, 18)}…`;
    case "DIDRevoked": return "revoked (final: no function re-activates a record)";
    case "DIDTransferred": return `owner ${l.args.previousOwner} -> ${l.args.newOwner}`;
    case "DIDExpiryChanged": return `expiry set to ${l.args.expiry === "0" ? "none" : new Date(Number(l.args.expiry) * 1000).toISOString()} by ${l.args.by}`;
    case "DIDExpired": return `expiry ${new Date(Number(l.args.expiryTimestamp) * 1000).toISOString()} already in the past when set`;
  }
}

export async function verifyDid(did: string, reader: ChainReader, opts: VerifyOptions): Promise<Report> {
  const { chainId: didChain, subject } = parseDid(did);
  const normalizedDid = `did:nhim:${didChain}:${subject.toLowerCase()}`;
  if (didChain !== opts.chainId) {
    throw new VerifierError(`This DID is for chain ${didChain}, but the verifier is pinned to chain ${opts.chainId}.`);
  }
  const rpcChain = await reader.chainId();
  if (Number(rpcChain) !== opts.chainId) {
    throw new VerifierError(`The RPC endpoint is on chain ${rpcChain}, not ${opts.chainId} (Sepolia). Use a Sepolia RPC URL.`);
  }

  const latest = await reader.latestBlock();
  const didId = await reader.computeDidId(subject);
  const record = await reader.getRecord(didId);
  const logs = await reader.logsFor(didId, opts.fromBlock, latest.number);
  logs.sort((a, b) => a.blockNumber - b.blockNumber || a.logIndex - b.logIndex);

  const txUrl = (h: string) => `${opts.explorer}/tx/${h}`;
  const times = new Map<number, number>();
  for (const bn of new Set(logs.map((l) => l.blockNumber))) times.set(bn, await reader.blockTime(bn));

  const history: HistoryItem[] = logs.map((l) => ({
    event: l.event,
    blockNumber: l.blockNumber,
    time: times.get(l.blockNumber)!,
    txHash: l.txHash,
    txUrl: txUrl(l.txHash),
    detail: detailFor(l),
  }));

  const report: Report = {
    did: normalizedDid, subject, didId, registry: opts.registry, chainId: opts.chainId,
    provider: reader.label, latestBlock: latest.number,
    existence: { verdict: "NOT FOUND", lines: [] },
    status: { verdict: "UNKNOWN", lines: [] },
    claims: { verdict: "NOT CHECKED", lines: [] },
    key: { verdict: "NOT CHECKED", lines: [] },
    history,
    overall: { verdict: "NOT FOUND", reasons: [] },
  };

  const registeredLogs = logs.filter((l) => l.event === "DIDRegistered");
  const exists = !!record && record.createdAt !== 0n && record.owner !== ZERO;

  // ---------- 1. Existence ----------
  if (!exists || !record) {
    report.existence.lines.push({ level: "BAD", text: "The registry has no record for this DID." });
    if (registeredLogs.length) report.existence.lines.push({ level: "WARN", text: "Registration events exist but the record is empty. Check the RPC provider." });
    report.overall = { verdict: "NOT FOUND", reasons: ["No record in the registry at " + opts.registry] };
    return report;
  }
  if (!same(record.subject, subject)) {
    throw new VerifierError(
      `The record's subject (${record.subject}) differs from the DID's address (${subject}). ` +
      "This usually means the built-in contract ABI does not match the deployed contract. Do not trust this output.",
    );
  }
  report.existence.verdict = "FOUND";
  report.existence.owner = record.owner;
  const issuerOk = opts.expectedIssuers.some((a) => same(a, record.owner));
  report.existence.issuer = issuerOk ? "EXPECTED ISSUER" : "UNVERIFIED ISSUER";
  report.existence.lines.push({ level: "OK", text: `Record found in registry ${opts.registry}.` });
  report.existence.lines.push(
    issuerOk
      ? { level: "OK", text: `Owner ${record.owner} is on the expected-issuer list.` }
      : { level: "BAD", text: `Owner ${record.owner} is NOT an expected issuer. Anyone could register a DID on an ungated registry, so this entry must not be treated as a Meashra identity.` },
  );

  // owner per logs vs owner per state
  const reg = registeredLogs[0];
  if (!reg) {
    report.existence.lines.push({ level: "WARN", text: `No DIDRegistered event found at or after block ${opts.fromBlock}. History may be incomplete; set --from-block to the registry's deployment block.` });
  } else {
    let ownerPerLogs = reg.args.owner;
    for (const l of logs) if (l.event === "DIDTransferred") ownerPerLogs = l.args.newOwner;
    if (!same(ownerPerLogs, record.owner)) {
      report.existence.lines.push({ level: "BAD", text: `Owner in registry state (${record.owner}) does not match the owner implied by the event log (${ownerPerLogs}).` });
    }
  }

  // ---------- 2. Status ----------
  const revokedLog = logs.find((l) => l.event === "DIDRevoked");
  const expiryLogs = logs.filter((l) => l.event === "DIDExpiryChanged");
  const loggedExpiry = expiryLogs.length ? BigInt(expiryLogs[expiryLogs.length - 1].args.expiry) : 0n;
  const st = report.status;
  const now = latest.timestamp;
  if (record.expiry !== 0n) st.expiry = Number(record.expiry);

  if (revokedLog || !record.isActive) {
    st.verdict = "REVOKED";
    if (revokedLog) {
      st.block = revokedLog.blockNumber;
      st.at = times.get(revokedLog.blockNumber);
      st.txHash = revokedLog.txHash;
      st.txUrl = txUrl(revokedLog.txHash);
      st.lines.push({ level: "INFO", text: `Revoked in block ${st.block} at ${new Date(st.at! * 1000).toISOString()}.` });
    } else {
      st.lines.push({ level: "WARN", text: "Registry state says inactive but no DIDRevoked event was found in range." });
    }
    if (revokedLog && record.isActive) st.lines.push({ level: "BAD", text: "A DIDRevoked event exists but registry state still says active. Treat as inconsistent." });
  } else if (record.expiry !== 0n && BigInt(now) > record.expiry) {
    st.verdict = "EXPIRED";
    st.lines.push({ level: "INFO", text: `Expired at ${new Date(Number(record.expiry) * 1000).toISOString()}.` });
  } else {
    st.verdict = "ACTIVE";
    const since = history.find((h) => h.event === "DIDRegistered");
    if (since) {
      st.block = since.blockNumber; st.at = since.time; st.txHash = since.txHash; st.txUrl = since.txUrl;
      st.lines.push({ level: "INFO", text: `Registered in block ${since.blockNumber} at ${new Date(since.time * 1000).toISOString()}.` });
    }
  }
  if (record.expiry !== 0n) {
    st.lines.push({ level: "INFO", text: `Expiry field is set: ${new Date(Number(record.expiry) * 1000).toISOString()}.` });
  }
  if (record.expiry !== loggedExpiry) {
    st.lines.push({
      level: "WARN",
      text: "The expiry in registry state does not match the last DIDExpiryChanged event. On a registry that predates that event, expiry can be changed (even an expired DID revived) without any log. Compare with the transaction history.",
    });
  }

  // ---------- 3. Claims integrity ----------
  const c = report.claims;
  const stateHash = hashOf(record.document);
  c.onChainHash = stateHash;
  c.verdict = "MATCH";
  const docEvents = logs.filter((l) => l.event === "DIDRegistered" || l.event === "DIDUpdated");
  if (docEvents.length) {
    const last = docEvents[docEvents.length - 1];
    const lastDoc = last.event === "DIDRegistered" ? last.args.document : last.args.newDocument;
    if (hashOf(lastDoc) === stateHash) {
      c.lines.push({ level: "OK", text: `Registry state and the latest ${last.event} event hold the same document (hash ${stateHash}).` });
    } else {
      c.verdict = "MISMATCH";
      c.lines.push({ level: "BAD", text: "Registry state differs from the document in the latest event." });
    }
  } else {
    c.lines.push({ level: "WARN", text: "No document events in range to compare against registry state." });
  }

  report.onChainDocument = record.document;
  let doc: any = null;
  try { doc = JSON.parse(record.document); } catch { /* handled below */ }
  if (doc === null) {
    c.verdict = "MISMATCH";
    c.lines.push({ level: "BAD", text: "The on-chain document is not valid JSON." });
  } else {
    const idOk = typeof doc.id === "string" && doc.id.toLowerCase() === normalizedDid;
    c.lines.push(idOk
      ? { level: "OK", text: "Document id equals this DID." }
      : { level: "BAD", text: `Document id (${String(doc.id)}) does not equal this DID.` });
    if (!idOk) c.verdict = "MISMATCH";
    const vms: any[] = Array.isArray(doc.verificationMethod) ? doc.verificationMethod : [];
    const keyBound = vms.some((v) => typeof v?.blockchainAccountId === "string" && v.blockchainAccountId.toLowerCase().endsWith(subject.toLowerCase()));
    c.lines.push(keyBound
      ? { level: "OK", text: "A verification method in the document is bound to the subject address." }
      : { level: "WARN", text: "No verification method in the document names the subject address." });
  }

  if (opts.presentedDocument !== undefined) {
    const exact = hashOf(opts.presentedDocument) === stateHash;
    const a = canonicalJson(opts.presentedDocument);
    const b = canonicalJson(record.document);
    if (exact) {
      c.lines.push({ level: "OK", text: "The document you presented is byte-identical to the on-chain document." });
    } else if (a !== null && a === b) {
      c.lines.push({ level: "OK", text: "The document you presented has the same content as the on-chain document (formatting differs)." });
    } else {
      c.verdict = "MISMATCH";
      c.lines.push({ level: "BAD", text: `The document you presented does not match the chain. On-chain hash ${stateHash}; presented hash ${hashOf(opts.presentedDocument)}.` });
    }
  }

  // ---------- 4. Control of key ----------
  const k = report.key;
  if (opts.signature && opts.challenge) {
    try {
      const rec = verifyMessage(opts.challenge, opts.signature);
      k.recovered = rec;
      if (same(rec, subject)) {
        k.verdict = "PASS";
        k.lines.push({ level: "OK", text: `The signature was made by the subject key ${subject}.` });
      } else {
        k.verdict = "FAIL";
        k.lines.push({ level: "BAD", text: `The signature was made by ${rec}, not by the subject ${subject}.` });
      }
    } catch (e) {
      k.verdict = "FAIL";
      k.lines.push({ level: "BAD", text: "The signature is not a valid signature of the challenge." });
    }
    if (!opts.challenge.toLowerCase().includes(normalizedDid)) {
      k.verdict = "FAIL";
      k.lines.push({ level: "BAD", text: "The challenge text does not name this DID, so it proves nothing about it." });
    }
  } else {
    k.lines.push({ level: "INFO", text: "Not checked: no signature supplied. Create a challenge, have the agent sign it, then pass the signature." });
  }

  // ---------- Overall ----------
  const reasons: string[] = [];
  if (!issuerOk) reasons.push("Owner is not an expected issuer");
  if (c.verdict === "MISMATCH") reasons.push("Claims do not match the chain");
  if (k.verdict === "FAIL") reasons.push("Key-control check failed");
  const hardBad = [...report.existence.lines, ...st.lines].some((l) => l.level === "BAD");
  if (hardBad) reasons.push("Registry state and event log disagree");
  if (reasons.length) {
    report.overall = { verdict: "NOT VERIFIED", reasons };
  } else if (st.verdict === "REVOKED" || st.verdict === "EXPIRED") {
    // Authentic record, but the identity must not be trusted: say so in the headline.
    report.overall = { verdict: st.verdict, reasons: [`Registered by an expected issuer; status ${st.verdict}. Do not trust this identity.`] };
  } else {
    report.overall = { verdict: "VERIFIED", reasons: ["Registered by an expected issuer; status ACTIVE"] };
  }
  return report;
}

/** Compare two reports (from two RPC providers) on the fields that matter. */
export function compareReports(a: Report, b: Report): string[] {
  const pick = (r: Report) => ({
    owner: r.existence.owner, issuer: r.existence.issuer, status: r.status.verdict,
    hash: r.claims.onChainHash, events: r.history.map((h) => `${h.event}:${h.blockNumber}:${h.txHash}`).join(","),
  });
  const x: any = pick(a), y: any = pick(b);
  return Object.keys(x).filter((k) => x[k] !== y[k]).map((k) => `${k}: ${a.provider} says ${x[k]}; ${b.provider} says ${y[k]}`);
}
