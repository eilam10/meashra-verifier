import { REGISTRY, DEFAULT_PUBLIC_RPC } from "./config.js";
import { verifyDid, makeChallenge, parseDid, VerifierError } from "./core.js";
import { ethersReader } from "./reader.js";

export { REGISTRY, DEFAULT_PUBLIC_RPC, makeChallenge, parseDid, VerifierError };

export async function run(did: string, rpc: string, opts: { challenge?: string; signature?: string; presentedDocument?: string; issuers?: string[] }) {
  return verifyDid(did, ethersReader(rpc, REGISTRY.address, REGISTRY.chainId), {
    registry: REGISTRY.address, chainId: REGISTRY.chainId, fromBlock: REGISTRY.deployBlock, explorer: REGISTRY.explorer,
    expectedIssuers: opts.issuers?.length ? opts.issuers : REGISTRY.defaultIssuers,
    challenge: opts.challenge, signature: opts.signature, presentedDocument: opts.presentedDocument,
  });
}
