import type { Line, Report } from "./types.js";

const MARK: Record<Line["level"], string> = { OK: "[ok]  ", WARN: "[warn]", BAD: "[BAD] ", INFO: "      " };
const iso = (t: number) => new Date(t * 1000).toISOString().replace(".000Z", "Z");

export function renderText(r: Report, explorer: string): string {
  const out: string[] = [];
  const section = (title: string, verdict: string, lines: Line[], extra: string[] = []) => {
    out.push("", `${title}: ${verdict}`);
    for (const e of extra) out.push("      " + e);
    for (const l of lines) out.push(`  ${MARK[l.level]} ${l.text}`);
  };
  out.push(`DID        ${r.did}`);
  out.push(`Registry   ${r.registry} (chain ${r.chainId})  ${explorer}/address/${r.registry}`);
  out.push(`RPC        ${r.provider}   latest block ${r.latestBlock}`);

  section("1. EXISTENCE", `${r.existence.verdict}${r.existence.issuer ? " / " + r.existence.issuer : ""}`, r.existence.lines);
  if (r.existence.verdict === "FOUND") {
    section("2. STATUS", r.status.verdict, r.status.lines, r.status.txUrl ? [`evidence: ${r.status.txUrl}`] : []);
    section("3. CLAIMS INTEGRITY", r.claims.verdict, r.claims.lines);
    section("4. CONTROL OF KEY", r.key.verdict, r.key.lines);
    out.push("", `5. HISTORY (${r.history.length} events, oldest first)`);
    if (!r.history.length) out.push("      none found in the searched range");
    for (const h of r.history) {
      out.push(`  ${iso(h.time)}  block ${h.blockNumber}  ${h.event}`);
      out.push(`      ${h.detail}`);
      out.push(`      ${h.txUrl}`);
    }
  }
  out.push("", `RESULT: ${r.overall.verdict}${r.overall.reasons.length ? "  (" + r.overall.reasons.join("; ") + ")" : ""}`);
  out.push("This shows what the registry says. It does not prove a registration was legitimate, and it trusts the RPC provider(s) you used.");
  return out.join("\n");
}
