import test from "node:test";
import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { writeFileSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Wallet, keccak256 } from "ethers";
import { startMock } from "./mock-rpc.mjs";

const REG = "0x57F1475b01E867F0E3E2bA1123c5c9F7021E548b";
const ISSUER = "0x7968dDA24aF04BEfF495e24Aa3655c5b3F2238F3";
const ATTACKER = "0x00000000000000000000000000000000000000aa";
const mk = () => { const w = Wallet.createRandom(); return { addr: w.address, did: `did:nhim:11155111:${w.address.toLowerCase()}`, id: keccak256(w.address.toLowerCase()) }; };
const A = mk(), B = mk(), C = mk(), D = mk(), E = mk();
let n = 1;
const tx = () => "0x" + (n++).toString(16).padStart(64, "0");
const reg = (x, block, owner = ISSUER) => ({ name: "DIDRegistered", block, tx: tx(), args: [x.id, x.addr, owner, JSON.stringify({ id: x.did })] });
const rev = (x, block) => ({ name: "DIDRevoked", block, tx: tx(), args: [x.id] });
const scenario = (logs, extra = {}) => ({ registry: REG, chainId: 11155111, latest: { number: 11870000, timestamp: 1791450000 }, logs, ...extra });

function run(args) {
  return new Promise((resolve) => {
    execFile("node", ["dist/cli.js", ...args], { encoding: "utf8", timeout: 20000 }, (err, stdout, stderr) =>
      resolve({ code: err ? (typeof err.code === "number" ? err.code : 99) : 0, out: stdout + stderr }));
  });
}
const inv = (lines) => { const p = join(mkdtempSync(join(tmpdir(), "inv-")), "inventory.txt"); writeFileSync(p, lines.join("\n")); return p; };

test("monitor: lists every registration, flags a registration by an unexpected owner", async () => {
  const m = await startMock(scenario([reg(A, 11863500), reg(B, 11863600), rev(B, 11864000), reg(C, 11865000, ATTACKER)]));
  const r = await run(["--monitor", "--rpc", m.url]); m.close();
  assert.equal(r.code, 1, r.out);
  assert.match(r.out, /3 DIDs ever registered \(2 active, 1 revoked\)/);
  assert.match(r.out, /NOT AN EXPECTED ISSUER/);
  assert.match(r.out, /Registered by an owner that is not an expected issuer/);
  assert.ok(r.out.includes(C.did));
  assert.match(r.out, /REVOKED/);
});

test("monitor: inventory diff finds an extra agent, a missing agent and a revoked one", async () => {
  const m = await startMock(scenario([reg(A, 11863500), reg(B, 11863600), rev(B, 11864000), reg(D, 11865000)]));
  const file = inv([`# our agents`, A.did, B.did, E.addr]);
  const r = await run(["--monitor", "--expected", file, "--rpc", m.url]); m.close();
  assert.equal(r.code, 1, r.out);
  assert.match(r.out, /Active in the registry but NOT in your inventory:\s+did:nhim:11155111:0x/);
  assert.ok(r.out.includes(D.did), "D is the unexpected registration");
  assert.match(r.out, /In your inventory but never registered/);
  assert.ok(r.out.includes(E.did));
  assert.match(r.out, /In your inventory but revoked on-chain/);
  assert.match(r.out, /RESULT: REVIEW FINDINGS/);
});

test("monitor: matching inventory is clean (exit 0)", async () => {
  const m = await startMock(scenario([reg(A, 11863500), reg(B, 11863600), rev(B, 11864000)]));
  const file = inv([A.did, B.did]);
  const r = await run(["--monitor", "--expected", file, "--rpc", m.url]);
  m.close();
  // B is revoked but in the inventory: that is a finding by design
  assert.equal(r.code, 1, r.out);
  const m2 = await startMock(scenario([reg(A, 11863500)]));
  const r2 = await run(["--monitor", "--expected", inv([A.did.toUpperCase().replace("0X", "0x"), ]), "--rpc", m2.url]);
  m2.close();
  assert.equal(r2.code, 0, r2.out);
  assert.match(r2.out, /RESULT: MATCHES INVENTORY/);
});

test("monitor: two providers agree, wrong-chain RPC is refused, bad inventory line errors", async () => {
  const logs = [reg(A, 11863500)];
  const m1 = await startMock(scenario(logs)), m2 = await startMock(scenario(logs));
  const r = await run(["--monitor", "--rpc", m1.url, "--rpc", m2.url]); m1.close(); m2.close();
  assert.equal(r.code, 0, r.out);
  assert.match(r.out, /CROSS-CHECK: 2 providers agree/);
  const m3 = await startMock(scenario(logs, { chainId: 1 }));
  const r3 = await run(["--monitor", "--rpc", m3.url]); m3.close();
  assert.equal(r3.code, 2, r3.out);
  assert.match(r3.out, /not 11155111/);
  const r4 = await run(["--monitor", "--expected", inv(["not a did"]), "--rpc", "http://127.0.0.1:1"]);
  assert.equal(r4.code, 2, r4.out);
  assert.match(r4.out, /Inventory line 1/);
});
